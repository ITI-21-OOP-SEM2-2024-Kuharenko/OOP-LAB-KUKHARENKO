﻿using System.Text.RegularExpressions;

Console.WriteLine(string.Join(Environment.NewLine, File.ReadAllText(@"D:\Laba\Cours 2\OOP C#\SEM 2\Lab 9\Linq9\test.txt")
    .Split(new[] { ' ', '\t', '\n', '\r', '.', ',', ';', ':', '!', '?' }, StringSplitOptions.RemoveEmptyEntries)
    .Select(word => Regex.Replace(word.ToLower(), "[^а-яА-Я]", ""))
    .Where(word => word.Length >= 4)
    .GroupBy(word => word)
    .Select(group => Tuple.Create(group.Key, group.Count()))
    .OrderByDescending(tuple => tuple.Item2)
    .Select(tuple => $"{tuple.Item1,15} {tuple.Item2,10}")));