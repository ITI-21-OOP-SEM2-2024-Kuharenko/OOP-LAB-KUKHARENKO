﻿using System.Reflection;
using CanineCenter.DAL.Interfaces;
using CanineCenter.Domain.Models;
using Microsoft.Data.SqlClient;

namespace CanineCenter.DAL.ADO.NET
{
    public class MSSQL : IDbContext
    {
        private readonly SqlConnection _connection;
        public List<Breed> Breeds { get; set; } = [];
        public List<Dog> Dogs {  get; set; } = [];

        public MSSQL()
        {
            _connection = MsSQLConnectionSingleton.Instance;
            SelectAll();
        }

        private void SelectAll()
        {
            _connection.Open();

            SqlCommand selectBreeds = new("SELECT * FROM Breeds", _connection);
            Breeds = Select<Breed>(selectBreeds);

            SqlCommand selectDogs = new("SELECT * FROM Dogs", _connection);
            Dogs = Select<Dog>(selectDogs);

            _connection.Close();
        }

        private List<T> Select<T>(SqlCommand command)
        {
            List<T> entities = [];
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    T entity = Activator.CreateInstance<T>();
                    PropertyInfo[] properties = typeof(T).GetProperties();

                    for (int i = 0; i < properties.Length; i++)
                    {
                        if (reader.GetName(i).Contains("Id") && i != 0)
                        {
                            int id = Convert.ToInt32(reader.GetValue(i));
                            if (entity is Breed)
                            {
                                Breed breed = Breeds.Find(x => x.BreedId == id)!;
                                properties[i].SetValue(entity, breed);
                            }
                            else if (entity is Dog)
                            {
                                Dog dog = Dogs.Find(x => x.DogId == id)!;
                                properties[i].SetValue(entity, dog);
                            }
                            else
                            {
                                properties[i].SetValue(entity, null);
                            }
                        }
                        else
                        {
                            object value = reader.GetValue(i);
                            Type propertyType = properties[i].PropertyType;

                            if (propertyType == typeof(DateOnly) && value is DateTime dateValue)
                            {
                                properties[i].SetValue(entity, new DateOnly(dateValue.Year, dateValue.Month, dateValue.Day));
                            }
                            else if (propertyType == typeof(Breed) && value is int breedId)
                            {
                                properties[i].SetValue(entity, Breeds.Find(x => x.BreedId == breedId));
                            }
                            else if (propertyType == typeof(Dog) && value is int dogId)
                            {
                                properties[i].SetValue(entity, Dogs.Find(x => x.DogId == dogId));
                            }
                            else
                            {
                                properties[i].SetValue(entity, Convert.ChangeType(value, propertyType));
                            }
                        }
                    }
                    entities.Add(entity);
                }
            }
            return entities;
        }

        private void InsertIntoBreeds()
        {
            string breedsStr = "";
            foreach(Breed breed in Breeds)
            {
                breedsStr += breed + ", ";
            }
            breedsStr = breedsStr.Remove(breedsStr.Length - 2);

            SqlCommand insertBreeds = new SqlCommand("INSERT INTO Breeds (BreedName, MinExteriorHeight, MaxExteriorHeight)" +
                                                     "VALUES " + breedsStr,_connection);
            insertBreeds.ExecuteNonQuery();
        }

        private void InsertIntoDogs()
        {
            string dogsStr = "";
            foreach (Dog dog in Dogs)
            {
                dogsStr += dog + ", ";
            }
            dogsStr = dogsStr.Remove(dogsStr.Length - 2);

            SqlCommand insertDogs = new SqlCommand("INSERT INTO Dogs (DogName, BreedId, BirthDate, ActualHeight)" +
                                                     "VALUES " + dogsStr, _connection);
            insertDogs.ExecuteNonQuery();
        }

        private void DeleteAll()
        {
            SqlCommand deleteDogs = new("DELETE FROM Dogs; DBCC CHECKIDENT ('Dogs', RESEED,0)", _connection);
            deleteDogs.ExecuteNonQuery();

            SqlCommand deleteBreeds = new("DELETE FROM Breeds; DBCC CHECKIDENT ('Breeds', RESEED,0)", _connection);
            deleteBreeds.ExecuteNonQuery();
        }

        private void UpdateAll()
        {
            DeleteAll();
            InsertIntoBreeds();
            InsertIntoDogs();
        }

        public void SaveChanges()
        {
            _connection.Open();

            UpdateAll();

            _connection.Close();
        }
    }
}
