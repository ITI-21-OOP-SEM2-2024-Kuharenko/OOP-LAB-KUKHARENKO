﻿using System.Data;
using CanineCenter.DAL.Interfaces;
using CanineCenter.Domain.Models;
using Microsoft.Data.SqlClient;

namespace CanineCenter.DAL.ADO.NET
{
    public class MSSQLDataSets : IDbContext
    {
        private readonly SqlConnection _connection;

        public List<Breed> Breeds { get; set; } = [];
        public List<Dog> Dogs { get; set; } = [];

        private readonly DataTable _dtDogs;
        private readonly DataTable _dtBreeds;

        public MSSQLDataSets()
        {
            _connection = MsSQLConnectionSingleton.Instance;

            SqlDataAdapter _adapterBreeds = new SqlDataAdapter("SELECT * FROM Breeds",_connection);
            SqlDataAdapter _adapterDogs = new SqlDataAdapter("SELECT * FROM Dogs",_connection);

            _dtDogs = new();
            _dtBreeds = new();

            _connection.Open();

            _adapterBreeds.Fill(_dtBreeds);
            _adapterDogs.Fill(_dtDogs);

            _connection.Close();
            SelectDogs();
        }

        private void SelectBreeds()
        {
            var queryBreeds = _dtBreeds.AsEnumerable().Select(breed => new
            {
                BreedId = breed.Field<int>("BreedId"),
                BreedName = breed.Field<string>("BreedName"),
                MinExteriorHeight = breed.Field<double>("MinExteriorHeight"),
                MaxExteriorHeight = breed.Field<double>("MaxExteriorHeight")
            });

            Breeds = [];
            foreach (var item in queryBreeds)
            {
                if (item.BreedName != null)
                {
                    Breeds.Add(new Breed
                    {
                        BreedId = item.BreedId,
                        BreedName = item.BreedName,
                        MaxExteriorHeight= item.MaxExteriorHeight,
                        MinExteriorHeight = item.MinExteriorHeight,
                    });
                }
            }
        }

        private void SelectDogs()
        {
            SelectBreeds();
            var queryDogs = _dtDogs.AsEnumerable().Select(dog => new
            {
                DogId = dog.Field<int>("DogId"),
                DogName = dog.Field<string>("DogName"),
                BreedId = dog.Field<int>("BreedId"),
                BirthDate = dog.Field<DateTime>("BirthDate"),
                ActualHeight = dog.Field<double>("ActualHeight")
            });

            Dogs = [];
            foreach (var item in queryDogs)
            {
                if (item.DogName != null)
                {
                    Breed breed = Breeds.Find(breed => breed.BreedId==item.BreedId)!;
                    Dogs.Add(new Dog
                    {
                        DogId = item.DogId,
                        DogName = item.DogName,
                        BirthDate = new DateOnly(item.BirthDate.Year, item.BirthDate.Month, item.BirthDate.Day),
                        ActualHeight = item.ActualHeight,
                        Breed = breed,
                    });
                }
            }
        }

        private void DeleteAll()
        {
            SqlDataAdapter adapter = new()
            {
                DeleteCommand = new("DELETE FROM Dogs; DBCC CHECKIDENT ('Dogs', RESEED,0)", _connection)
            };
            adapter.DeleteCommand.ExecuteNonQuery();
            _dtDogs.Clear();
            adapter.Update(_dtDogs);
            _dtDogs.AcceptChanges();

            adapter = new()
            {
                DeleteCommand = new("DELETE FROM Breeds; DBCC CHECKIDENT ('Breeds', RESEED,0)", _connection)
            };
            adapter.DeleteCommand.ExecuteNonQuery();
            _dtBreeds.Clear();
            adapter.Update(_dtBreeds);
            _dtBreeds.AcceptChanges();
        }

        private void InsertIntoBreeds()
        {
            foreach (var item in Breeds)
            {
                DataRow row = _dtBreeds.NewRow();
                row["BreedId"] = item.BreedId;
                row["BreedName"] = item.BreedName;
                row["MinExteriorHeight"] = item.MinExteriorHeight;
                row["MaxExteriorHeight"] = item.MaxExteriorHeight;

                _dtBreeds.Rows.Add(row);
            }
            SqlDataAdapter adapter = new()
            {
                InsertCommand = new("INSERT INTO Breeds (BreedName, MinExteriorHeight, MaxExteriorHeight) " +
                                    "VALUES (@BreedName, @MinExteriorHeight, @MaxExteriorHeight)", _connection)
            };
            adapter.InsertCommand.Parameters.Add("@BreedName", SqlDbType.VarChar, 50, "BreedName");
            adapter.InsertCommand.Parameters.Add("@MinExteriorHeight", SqlDbType.Float, 8, "MinExteriorHeight");
            adapter.InsertCommand.Parameters.Add("@MaxExteriorHeight", SqlDbType.VarChar, 8, "MaxExteriorHeight");

            adapter.Update(_dtBreeds);
            _dtBreeds.AcceptChanges();
        }

        private void InsertIntoDogs()
        {
            foreach (var item in Dogs)
            {
                DataRow row = _dtDogs.NewRow();
                row["DogId"] = item.DogId;
                row["DogName"] = item.DogName;
                row["BreedId"] = item.Breed.BreedId;
                row["BirthDate"] = new DateTime(item.BirthDate.Year, item.BirthDate.Month, item.BirthDate.Day);
                row["ActualHeight"] = item.ActualHeight;

                _dtDogs.Rows.Add(row);
            }
            SqlDataAdapter adapter = new()
            {
                InsertCommand = new("INSERT INTO Dogs (DogName, BreedId, BirthDate, ActualHeight) " +
                                    "VALUES (@DogName, @BreedId, @BirthDate, @ActualHeight)", _connection)
            };
            adapter.InsertCommand.Parameters.Add("@DogName", SqlDbType.VarChar, 50, "DogName");
            adapter.InsertCommand.Parameters.Add("@BreedId", SqlDbType.Int, 4, "BreedId");
            adapter.InsertCommand.Parameters.Add("@BirthDate", SqlDbType.Date, 3, "BirthDate");
            adapter.InsertCommand.Parameters.Add("@ActualHeight", SqlDbType.Float, 8, "ActualHeight");

            adapter.Update(_dtDogs);
            _dtDogs.AcceptChanges();
        }

        private void UpdateAll()
        {
            DeleteAll();
            InsertIntoBreeds();
            InsertIntoDogs();
        }

        public void SaveChanges()
        {
            _connection.Open();

            UpdateAll();

            _connection.Close();
        }
    }
}
