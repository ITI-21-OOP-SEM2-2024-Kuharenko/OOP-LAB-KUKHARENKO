﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CanineCenter.Domain.Models;

namespace CanineCenter.DAL.Interfaces
{
    public interface IDbContext
    {
        List<Breed> Breeds { get; set; }
        List<Dog> Dogs { get; set; }
        void SaveChanges();
    }
}
