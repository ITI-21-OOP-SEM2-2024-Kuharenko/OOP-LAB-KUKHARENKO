﻿using Microsoft.Data.SqlClient;

namespace CanineCenter.DAL
{
    public sealed class MsSQLConnectionSingleton
    {
        private static readonly SqlConnection instance = CreateInstance();
        public static SqlConnection Instance => instance;
        private MsSQLConnectionSingleton() { }
        private static SqlConnection CreateInstance()
        {
            string connectionString = "Server=KENG;Database=CanineCenter;Trusted_Connection=True;TrustServerCertificate=true;";
            return new SqlConnection(connectionString);
        }
    }
}
