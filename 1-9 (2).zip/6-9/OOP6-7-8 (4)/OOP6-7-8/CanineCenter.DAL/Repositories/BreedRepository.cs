﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CanineCenter.DAL.Interfaces;
using CanineCenter.Domain.Models;

namespace CanineCenter.DAL.Repositories
{
    public class BreedRepository(IDbContext dbContext) : IRepository<Breed>
    {
        private readonly IDbContext _dbContext = dbContext;
        public bool Delete(Breed entity)
        {
            bool IsRemove = _dbContext.Breeds.Remove(entity);
            _dbContext.SaveChanges();
            return IsRemove;
        }

        public List<Breed> GetAll()
        {
            return _dbContext.Breeds;
        }

        public Breed GetById(int id)
        {
            return _dbContext.Breeds.Find(x => x.BreedId == id)!;
        }

        public bool Insert(Breed entity)
        {
            _dbContext.Breeds.Add(entity);
            _dbContext.SaveChanges();
            return true;
        }

        public bool Update(Breed oldEntity, Breed newEntity)
        {
            Breed? breedToUpdate = _dbContext.Breeds.Find(breed => breed == oldEntity);
            newEntity.BreedId = oldEntity.BreedId;

            if(breedToUpdate != null)
            {
                breedToUpdate.BreedId = newEntity.BreedId;
                breedToUpdate.BreedName = newEntity.BreedName;
                breedToUpdate.MaxExteriorHeight = newEntity.MaxExteriorHeight;
                breedToUpdate.MinExteriorHeight = newEntity.MinExteriorHeight;

                _dbContext.SaveChanges();
                return true;
            }
            else
            {
                throw new ArgumentNullException($"Порода не найдена в базе данных для обновления:{breedToUpdate}");
            }
        }
    }
}
