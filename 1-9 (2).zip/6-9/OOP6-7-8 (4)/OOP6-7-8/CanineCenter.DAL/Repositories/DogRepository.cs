﻿using CanineCenter.DAL.Interfaces;
using CanineCenter.Domain.Models;

namespace CanineCenter.DAL.Repositories
{
    public class DogRepository(IDbContext dbContext) : IRepository<Dog>
    {
        private readonly IDbContext _dbContext = dbContext;

        public bool Delete(Dog entity)
        {
            bool IsRemove = _dbContext.Dogs.Remove(entity);
            _dbContext.SaveChanges();
            return IsRemove;
        }

        public List<Dog> GetAll()
        {
            return _dbContext.Dogs;
        }

        public Dog GetById(int id)
        {
            return _dbContext.Dogs.Find(dog => dog.DogId == id)!;
        }

        public bool Insert(Dog entity)
        {
            _dbContext.Dogs.Add(entity);
            _dbContext.SaveChanges();
            return true;
        }

        public bool Update(Dog oldEntity, Dog newEntity)
        {
            Dog? dogToUpdate = _dbContext.Dogs.Find(dog => dog == oldEntity);
            newEntity.DogId = oldEntity.DogId;

            if(dogToUpdate != null)
            {
                dogToUpdate.DogId = newEntity.DogId;
                dogToUpdate.DogName = newEntity.DogName;
                dogToUpdate.Breed = newEntity.Breed;
                dogToUpdate.BirthDate = newEntity.BirthDate;
                dogToUpdate.ActualHeight = newEntity.ActualHeight;

                _dbContext.SaveChanges();
                return true;
            }
            else
            {
                throw new ArgumentNullException($"Собака не найдена в базе данных для обновления:{dogToUpdate}");
            }    
        }
    }
}
