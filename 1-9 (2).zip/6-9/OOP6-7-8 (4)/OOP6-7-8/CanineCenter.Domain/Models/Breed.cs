﻿using CanineCenter.Domain.ViewModels;

namespace CanineCenter.Domain.Models
{
    public class Breed(int BreedId, string BreedName, double MinExterioiHeight, float MaxExteriorHeight)
    {
        public int BreedId { get; set; } = BreedId;
        public string BreedName { get; set; } = BreedName;
        public double MinExteriorHeight { get; set; } = MinExterioiHeight;
        public double MaxExteriorHeight { get;set; } = MaxExteriorHeight;

        public Breed() : this(0,"",0,0) { }

        public static implicit operator Breed(BreedViewModel breedViewModel)
        {
            return new Breed()
            {
                BreedId = 0,
                BreedName = breedViewModel.BreedName,
                MinExteriorHeight = breedViewModel.MinExteriorHeight,
                MaxExteriorHeight = breedViewModel.MaxExteriorHeight,
            };
        }

        public override string ToString()
        {
            return $"('{BreedName}', {MinExteriorHeight}, {MaxExteriorHeight})";
        }
    }
}
