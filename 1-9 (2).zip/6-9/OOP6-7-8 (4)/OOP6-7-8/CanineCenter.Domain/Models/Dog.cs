﻿using CanineCenter.Domain.ViewModels;

namespace CanineCenter.Domain.Models
{
    public class Dog(int dogId, string dogName, Breed breed, DateOnly birthDate, double actualHeight)
    {
        public int DogId { get; set; } = dogId;
        public string DogName { get; set;} = dogName;
        public Breed Breed { get; set;} = breed;
        public DateOnly BirthDate { get; set; } = birthDate;
        public double ActualHeight { get; set; } = actualHeight;

        public Dog() : this(0,"",new Breed(),new DateOnly(),0) { }

        public static implicit operator Dog(DogViewModel dogViewModel)
        {
            return new Dog
            {
                DogId = 0,
                DogName = dogViewModel.DogName,
                Breed = new Breed(),
                BirthDate = dogViewModel.BirthDate,
                ActualHeight = dogViewModel.ActualHeight,
            };
        }

        public override string ToString()
        {
            return $"('{DogName}', {Breed.BreedId}, '{BirthDate}', {ActualHeight})";
        }
    }
}
