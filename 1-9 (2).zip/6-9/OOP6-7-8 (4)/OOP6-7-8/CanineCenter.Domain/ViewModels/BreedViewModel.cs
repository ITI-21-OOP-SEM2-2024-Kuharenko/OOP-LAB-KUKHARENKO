﻿using System.ComponentModel;
using CanineCenter.Domain.Models;

namespace CanineCenter.Domain.ViewModels
{
    public class BreedViewModel(Breed breed)
    {
        [DisplayName("Порода")]
        public string BreedName { get; set; } = breed.BreedName;

        [DisplayName("Минимальный рост по экстерьеру")]
        public double MinExteriorHeight { get; set; } = breed.MinExteriorHeight;

        [DisplayName("Максимальный рост по экстерьеру")]
        public double MaxExteriorHeight { get; set; } = breed.MaxExteriorHeight;

        public BreedViewModel() : this(new Breed()) { }

        public BreedViewModel(string breedName, float minExteriorHeight, double maxExteriorHeight):this()
        {
            BreedName = breedName;
            MinExteriorHeight = minExteriorHeight;
            MaxExteriorHeight= maxExteriorHeight;
        }
        public static implicit operator BreedViewModel(Breed breed)
        {
            return new BreedViewModel(breed);
        }
    }
}
