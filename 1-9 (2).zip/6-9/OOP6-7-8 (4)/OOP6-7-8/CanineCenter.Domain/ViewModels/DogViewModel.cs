﻿using System.ComponentModel;
using CanineCenter.Domain.Models;

namespace CanineCenter.Domain.ViewModels
{
    public class DogViewModel(Dog dog)
    {
        [DisplayName("Кличка")]
        public string DogName { get; set; } = dog.DogName;

        [DisplayName("Порода")]
        public string BreedName { get; set; } = dog.Breed.BreedName;

        [DisplayName("День рождения")]
        public DateOnly BirthDate { get; set; } = dog.BirthDate;

        [DisplayName("Рост")]
        public double ActualHeight { get; set; } = dog.ActualHeight;

        public DogViewModel() : this(new Dog()) { }

        public DogViewModel(string dogName, string breedName, DateOnly birthDate, double actualHeight):this()
        {
            DogName = dogName;
            BreedName = breedName;
            BirthDate = birthDate;
            ActualHeight = actualHeight;
        }

        public static implicit operator DogViewModel(Dog dog)
        {
            return new DogViewModel(dog);
        }
    }
}
