﻿using CanineCenter.DAL.Interfaces;
using CanineCenter.Domain.Models;
using CanineCenter.Domain.ViewModels;

namespace CanineCenter.Service.Services
{
    public class BreedService(IRepository<Breed> breedRepository)
    {
        private readonly IRepository<Breed> _breedRepository = breedRepository;

        public bool Insert(BreedViewModel breedViewModel)
        {
            try
            {
                Breed breed = breedViewModel;
                return _breedRepository.Insert(breed);
            }
            catch
            {
                throw new Exception($"[Insert Breed]");
            }
        }

        public bool Delete(string breedName)
        {
            try
            {
                Breed breed = _breedRepository.GetAll().Find(x => x.BreedName == breedName)!;
                ArgumentNullException.ThrowIfNull(breed);

                return _breedRepository.Delete(breed);
            }
            catch
            {
                throw new Exception($"[Delete Breed]");
            }
        }

        public bool Update(BreedViewModel breedViewModel, string breedName)
        {
            try
            {
                Breed oldBreed = _breedRepository.GetAll().Find(x => x.BreedName == breedName)!;
                Breed newBreed = breedViewModel;
                ArgumentNullException.ThrowIfNull(oldBreed);
                ArgumentNullException.ThrowIfNull(newBreed);

                return _breedRepository.Update(oldBreed, newBreed);
            }
            catch
            {
                throw new Exception($"[Update Breed]");
            }
        }

        public List<BreedViewModel> GetAll()
        {
            try
            {
                List<Breed> breeds = _breedRepository.GetAll();
                List<BreedViewModel> breedViewModels = [];
                for(int i = 0; i < breeds.Count; i++)
                {
                    ArgumentNullException.ThrowIfNull(breeds[i]);
                    breedViewModels.Add(breeds[i]);
                }
                return breedViewModels;
            }
            catch
            {
                throw new Exception($"[GetAll Breed]");
            }
        }

        public BreedViewModel GetById(int id)
        {
            try
            {
                Breed breed = _breedRepository.GetById(id);
                BreedViewModel breedViewModel = breed;
                return breedViewModel;
            }
            catch
            {
                throw new Exception($"[GetById Breed]");
            }
        }
    }
}
