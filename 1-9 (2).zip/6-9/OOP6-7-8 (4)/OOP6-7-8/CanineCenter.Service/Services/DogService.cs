﻿using CanineCenter.DAL.Interfaces;
using CanineCenter.Domain.Models;
using CanineCenter.Domain.ViewModels;

namespace CanineCenter.Service.Services
{
    public class DogService(IRepository<Dog> dogRepository, IRepository<Breed> breedRepository)
    {
        private readonly IRepository<Breed> _breedRepository = breedRepository;
        private readonly IRepository<Dog> _dogRepository = dogRepository;

        public bool Insert(DogViewModel dogViewModel)
        {
            try
            {
                Dog dog = dogViewModel;
                Breed breed = _breedRepository.GetAll().First(x => x.BreedName == dogViewModel.BreedName);
                ArgumentNullException.ThrowIfNull(breed);

                dog.Breed = breed;

                return _dogRepository.Insert(dog);
            }
            catch
            {
                throw new Exception($"[Insert Dog]");
            }
        }

        public bool Delete(string dogName)
        {
            try
            {
                Dog dog = _dogRepository.GetAll().Find(x => x.DogName == dogName)!;
                ArgumentNullException.ThrowIfNull(dog);

                return _dogRepository.Delete(dog);
            }
            catch
            {
                throw new Exception($"[Delete Dog]");
            }
        }

        public bool Update(DogViewModel dogViewModel, string dogName)
        {
            try
            {
                Dog oldDog = _dogRepository.GetAll().Find(x => x.DogName == dogName)!;
                Dog newDog = dogViewModel;
                ArgumentNullException.ThrowIfNull(newDog);
                ArgumentNullException.ThrowIfNull(oldDog);

                Breed breed = _breedRepository.GetAll().Find(x => x.BreedName == dogViewModel.BreedName)!;
                ArgumentNullException.ThrowIfNull(breed);

                newDog.Breed = breed;

                return _dogRepository.Update(oldDog, newDog);
            }
            catch
            {
                throw new Exception($"[Update Dog]");
            }
        }

        public List<DogViewModel> GetAll()
        {
            try
            {
                List<Dog> dogs = _dogRepository.GetAll();
                List<DogViewModel> dogViewModels = [];
                for(int i = 0; i < dogs.Count; i++)
                {
                    ArgumentNullException.ThrowIfNull(dogs[i]);
                    dogViewModels.Add(dogs[i]);
                }
                return dogViewModels;
            }
            catch
            {
                throw new Exception($"[GetAll Dog]");
            }
        }

        public DogViewModel GetById(int id)
        {
            try
            {
                Dog dog = _dogRepository.GetById(id);
                DogViewModel dogViewModel = dog;
                return dogViewModel;
            }
            catch
            {
                throw new Exception($"[GetById Dog]");
            }
        }

        public List<DogViewModel> SearchDogsByBreed(string breed)
        {
            try
            {
                List<Dog> dogs = _dogRepository.GetAll().Where(x=>x.Breed.BreedName==breed).ToList();
                List<DogViewModel> dogViewModels = [];
                for(int i=0; i < dogs.Count;i++)
                {
                    ArgumentNullException.ThrowIfNull(dogs[i]);
                    dogViewModels.Add(dogs[i]);
                }
                return dogViewModels;
            }
            catch
            {
                throw new Exception($"[GetByBreed Dog]");
            }
        }

        public List<DogViewModel> SearchDogsByName(string dogName)
        {
            try
            {
                List<Dog> dogs = _dogRepository.GetAll().Where(x => x.DogName.ToLower().StartsWith(dogName.ToLower())).ToList();
                List<DogViewModel> dogViewModels = [];
                for (int i = 0; i < dogs.Count; i++)
                {
                    ArgumentNullException.ThrowIfNull(dogs[i]);
                    dogViewModels.Add(dogs[i]);
                }
                return dogViewModels;
            }
            catch
            {
                throw new Exception($"[GetByName Dog]");
            }
        }

        public int Count() => GetAll().Count();
        public double ActualHeightAvg() => GetAll().Average(x=>x.ActualHeight);
        public double ActualHeightMin() => GetAll().Min(x=>x.ActualHeight);
        public double ActualHeightMax() => GetAll().Max(x=>x.ActualHeight);

        public DateOnly BirthDateMin() => GetAll().Min(x => x.BirthDate);
        public DateOnly BirthDateMax() => GetAll().Max(x => x.BirthDate);
    }
}
