﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using CanineCenter.DAL.ADO.NET;
using CanineCenter.DAL.Interfaces;
using CanineCenter.DAL.Repositories;
using CanineCenter.Domain.Models;
using CanineCenter.Service.Services;
using OOP6_7_8.Pages;
using OOP6_7_8.Views;

namespace OOP6_7_8
{
    public partial class MainWindow : Window
    {
        private readonly BreedService _breedService;
        private readonly DogService _dogService;
        private readonly IDbContext dbContext;
        public MainWindow()
        {
            InitializeComponent();

            dbContext = new MSSQLDataSets();

            dbContext.Breeds = [
                new(1,"Немецкая овчарка",60,65),
                new(2,"Лабрадор",55,62),
                new(3,"Ротвейлер", 65,70),
                new(4,"Бульдог",50,55),
                new(5,"Йоркширский терьер",20,25)
                ];

            dbContext.Dogs = [
                new(1,"Барон",dbContext.Breeds.Find(x => x.BreedId == 1)!,new DateOnly(2019,5,10),65),
                new(2,"Рекс",dbContext.Breeds.Find(x => x.BreedId == 2)!,new DateOnly(2020,2,15),55),
                new(3,"Лайка",dbContext.Breeds.Find(x => x.BreedId == 1)!,new DateOnly(2018,11,20),60),
                new(4,"Макс",dbContext.Breeds.Find(x => x.BreedId == 3)!,new DateOnly(2017,8,5),66),
                new(5,"Шарик",dbContext.Breeds.Find(x => x.BreedId == 4)!,new DateOnly(2021,1,8),53),
                new(6,"Тузик",dbContext.Breeds.Find(x => x.BreedId == 3)!,new DateOnly(2019,7,12),68),
                new(7,"Бобик",dbContext.Breeds.Find(x => x.BreedId == 5)!,new DateOnly(2020,9,25),24),
                new(8,"Ричи",dbContext.Breeds.Find(x => x.BreedId == 2)!,new DateOnly(2016,4,2),57),
                new(9,"Джек",dbContext.Breeds.Find(x => x.BreedId == 3)!,new DateOnly(2015,12,10),69),
                new(10,"Майло",dbContext.Breeds.Find(x => x.BreedId == 1)!,new DateOnly(2021,3,18),61),
                ];

            dbContext.SaveChanges();

            IRepository<Breed> breedRepository = new BreedRepository(dbContext);
            IRepository<Dog> dogRepository = new DogRepository(dbContext);

            _breedService = new BreedService(breedRepository);
            _dogService = new DogService(dogRepository, breedRepository);
        }

        private void dataGrid_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyDescriptor is PropertyDescriptor descriptor)
            {
                e.Column.Header = descriptor.DisplayName;
            }
        }

        private void BreedsAllButton_Click(object sender, RoutedEventArgs e)
        {
            dataGrid.ItemsSource = _breedService.GetAll();
        }

        private void DogsAllButton_Click(object sender, RoutedEventArgs e)
        {
            dataGrid.ItemsSource= _dogService.GetAll();
        }

        private void SearchDogButton_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = new SearchPage(_breedService, _dogService);
        }
        private void SearchDogNameButton_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = new SearchDogNamePage(_dogService, dataGrid);
        }
        private void AggButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Общее количесво записей: {_dogService.Count()};\n" +
                            $"Средний рост по всем собакам: {_dogService.ActualHeightAvg()};\n" +
                            $"Минимальный рост по всем собакам: {_dogService.ActualHeightMin()};\n" +
                            $"Максимальная рост по всем собакам: {_dogService.ActualHeightMax()};\n" +
                            $"Последняя дата рождения по всем собакам: {_dogService.BirthDateMax()};\n" +
                            $"Первая дата рождения по всем собакам: {_dogService.BirthDateMin()};\n");
        }

        private void addItem_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = new AddDogPage(_breedService, dataGrid, _dogService);
        }

        private void deleteItem_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = new DeletePage(_dogService, dataGrid);
        }

        private void updateItem_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = new UpdatePage(_dogService, dataGrid, _breedService);
        }
        private void ShowDogButton_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = new DogDataGridPage(_breedService, _dogService, dbContext);
        }
        private void PageFrame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }
    }
}