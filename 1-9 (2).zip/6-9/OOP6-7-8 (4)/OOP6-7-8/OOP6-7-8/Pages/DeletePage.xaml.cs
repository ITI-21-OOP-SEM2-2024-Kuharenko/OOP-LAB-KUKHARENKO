﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CanineCenter.Service.Services;

namespace OOP6_7_8.Pages
{
    /// <summary>
    /// Логика взаимодействия для DeletePage.xaml
    /// </summary>
    public partial class DeletePage : Page
    {
        private readonly DogService _dogService;
        private readonly DataGrid _grid;
        public DeletePage(DogService dogService, DataGrid grid)
        {
            InitializeComponent();
            _dogService = dogService;
            _grid = grid;
        }

        private void submitButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(dogName.Text != string.Empty)
                {
                    _dogService.Delete(dogName.Text);
                    MessageBox.Show("Данные успешно удалены");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            Content = null;
            _grid.ItemsSource = _dogService.GetAll();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            Content = null;
        }
    }
}
