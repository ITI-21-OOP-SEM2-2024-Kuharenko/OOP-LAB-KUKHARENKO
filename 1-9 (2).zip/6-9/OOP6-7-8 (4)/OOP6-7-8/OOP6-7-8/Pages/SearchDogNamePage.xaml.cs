﻿using CanineCenter.Domain.ViewModels;
using CanineCenter.Service.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OOP6_7_8.Pages
{
    /// <summary>
    /// Логика взаимодействия для SearchDogName.xaml
    /// </summary>
    public partial class SearchDogNamePage : Page
    {
        private readonly DogService _dogService;
        private readonly DataGrid dataGrid;
        public SearchDogNamePage( DogService dogService, DataGrid dataGrid)
        {
            InitializeComponent();
            _dogService = dogService;
            this.dataGrid = dataGrid;
        }

        private void datagrid_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyDescriptor is PropertyDescriptor descriptor)
            {
                e.Column.Header = descriptor.DisplayName;
            }
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            Content = null;
        }

        private void dogName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dogNamebox.Text != string.Empty)
            {
                List<DogViewModel> dogs = _dogService.SearchDogsByName(dogNamebox.Text);
                if(dogs != null)
                {
                    datagrid.ItemsSource = dogs;
                }
                else datagrid.ItemsSource = null;
            }
            
        }
        //private void submitButton_Click(object sender, RoutedEventArgs e)
        //{
        //    string dogNameStr = dogNamebox.Text;
        //    if (dogNameStr != string.Empty)
        //    {
        //        dataGrid.ItemsSource = _dogService.SearchDogsByName(dogNameStr);
        //        Content = null;
        //    }
        //}
    }
}
