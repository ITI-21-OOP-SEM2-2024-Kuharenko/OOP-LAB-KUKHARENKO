﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CanineCenter.Service.Services;

namespace OOP6_7_8.Pages
{
    /// <summary>
    /// Логика взаимодействия для SearchPage.xaml
    /// </summary>
    public partial class SearchPage : Page
    {
        private readonly DogService _dogService;
        private readonly BreedService _breedService;
        private readonly DataGrid dataGrid;
        public SearchPage(BreedService breedService, DogService dogService)
        {
            InitializeComponent();
            _breedService = breedService;
            _dogService = dogService;
            breedName.ItemsSource = _breedService.GetAll().Select(x => x.BreedName).Distinct();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            Content = null;
        }

        private void submitButton_Click(object sender, RoutedEventArgs e)
        {
            string breedNameStr = breedName.SelectedItem.ToString()!.Trim();
            if(breedNameStr != string.Empty)
            {
                dataGrid.ItemsSource = _dogService.SearchDogsByBreed(breedNameStr);
                Content = null;
            }
        }
    }
}
