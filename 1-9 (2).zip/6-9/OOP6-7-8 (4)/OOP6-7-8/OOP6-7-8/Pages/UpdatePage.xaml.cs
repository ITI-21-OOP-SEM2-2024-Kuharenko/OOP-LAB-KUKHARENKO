﻿using System.Windows;
using System.Windows.Controls;
using CanineCenter.Domain.Models;
using CanineCenter.Domain.ViewModels;
using CanineCenter.Service.Services;

namespace OOP6_7_8.Pages
{
    /// <summary>
    /// Логика взаимодействия для UpdatePage.xaml
    /// </summary>
    public partial class UpdatePage : Page
    {
        private readonly DogService _dogService;
        private readonly BreedService _breedService;
        private readonly DataGrid dataGrid;
        public UpdatePage(DogService dogService, DataGrid dataGrid, BreedService breedService)
        {
            InitializeComponent();
            _dogService = dogService;
            this.dataGrid = dataGrid;
            _breedService = breedService;
            comboBoxBreeds.ItemsSource = _breedService.GetAll().Select(x => x.BreedName).Distinct();
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            Content = null;
        }

        private void submitButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DogViewModel dogViewModel = new();
                if (comboBoxBreeds.SelectedItem != null)
                {
                    if (dogName.Text != string.Empty)
                    {
                        if (DateOnly.TryParse(birthDate.Text, out DateOnly BirthDate))
                        {
                            if (double.TryParse(actualHeight.Text, out double ActualHeight))
                            {
                                dogViewModel = new DogViewModel
                                {
                                    DogName = dogName.Text,
                                    BirthDate = BirthDate,
                                    ActualHeight = ActualHeight,
                                    BreedName = comboBoxBreeds.SelectedItem.ToString()!
                                };
                            }
                        }
                    }
                }
                if(dogName.Text.Trim() != string.Empty)
                {
                    _dogService.Update(dogViewModel,dogName.Text.Trim());
                    MessageBox.Show("Данные успешно обновлены");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            Content = null;
            dataGrid.ItemsSource = _dogService.GetAll();
        }

        private void dogName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(dogName.Text!= string.Empty)
            {
                DogViewModel dog = _dogService.GetAll().Find(x=>x.DogName==dogName.Text.Trim())!;
                if(dog != null)
                {
                    comboBoxBreeds.SelectedItem = dog.BreedName;
                    actualHeight.Text = dog.ActualHeight.ToString();
                    birthDate.Text = dog.BirthDate.ToString();
                }

            }
            else
            {
                comboBoxBreeds.SelectedItem = null;
                actualHeight.Text = "";
                birthDate.Text = "";
            }
        }
    }
}
