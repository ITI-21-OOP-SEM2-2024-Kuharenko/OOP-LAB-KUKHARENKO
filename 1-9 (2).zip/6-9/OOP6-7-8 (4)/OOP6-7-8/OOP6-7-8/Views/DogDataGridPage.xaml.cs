﻿using CanineCenter.DAL.Interfaces;
using CanineCenter.Domain.Models;
using CanineCenter.Domain.ViewModels;
using CanineCenter.Service.Services;
using OOP6_7_8.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OOP6_7_8.Views
{
    /// <summary>
    /// Логика взаимодействия для DogDataGridPage.xaml
    /// </summary>
    public partial class DogDataGridPage : Page
    {
        private readonly BreedService _breedService;
        private readonly DogService _dogService;
        private readonly IDbContext _dbContext;
        public DogDataGridPage(BreedService breedService, DogService dogService, IDbContext dbContext)
        {
            InitializeComponent();
            _dogService = dogService;
            dataGrid.ItemsSource = _dogService.GetAll();
            _breedService = breedService;
            BreedNameCombo.ItemsSource = _dogService.GetAll().Select(x => x.BreedName).Distinct();
            _dbContext = dbContext;
        }

        private void dataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            DogViewModel dogViewModel = (e.Row.Item as DogViewModel)!;
            if (dataGrid.SelectedIndex != dataGrid.Items.Count -2 )
            {
                if (dogViewModel != null)
                {
                    _dogService.Update(dogViewModel, dogViewModel.DogName);
                    MessageBox.Show("Данные успешно изменены");
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void addItem_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = new AddDogPage(_breedService, dataGrid, _dogService);
        }

        private void deleteItem_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = new DeletePage(_dogService, dataGrid);
        }

        private void updateItem_Click(object sender, RoutedEventArgs e)
        {
            PageFrame.Content = new UpdatePage(_dogService, dataGrid, _breedService);
        }

        private void dataGrid_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Delete)
            {
                DogViewModel dogViewModel = (dataGrid.SelectedItem as DogViewModel)!;
                if (dogViewModel != null)
                {
                    _dogService.Delete(dogViewModel.DogName);
                    MessageBox.Show("Данные успешно удалены");
                }
            }

            if (e.Key == Key.S && Keyboard.Modifiers == ModifierKeys.Control)
            {
                e.Handled = true;

                DogViewModel dogViewModel = (dataGrid.SelectedItem as DogViewModel)!;
                if (dogViewModel != null)
                {
                    string breedname = dogViewModel.BreedName;
                    if (dogViewModel.ActualHeight >= _dbContext.Breeds.Find(x => x.BreedName == breedname).MinExteriorHeight
                        && dogViewModel.ActualHeight <= _dbContext.Breeds.Find(x => x.BreedName == breedname).MaxExteriorHeight)
                    {
                        _dogService.Insert(dogViewModel);
                        MessageBox.Show("Данные успешно добавлены");
                    }
                    else
                    {
                        MessageBox.Show("Рост не соответствует экстерьеру породы");
                    }
                }
            }
        }
    }
}
