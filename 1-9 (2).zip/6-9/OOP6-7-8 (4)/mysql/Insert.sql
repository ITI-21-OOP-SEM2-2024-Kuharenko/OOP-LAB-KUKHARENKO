Use CanineCenter;

CREATE TABLE Breeds (
    BreedId INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
    BreedName VARCHAR(50) NOT NULL UNIQUE,
    MinExteriorHeight FLOAT NOT NULL,
    MaxExteriorHeight FLOAT NOT NULL
);

CREATE TABLE Dogs (
    DogId INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
    DogName VARCHAR(50) NOT NULL UNIQUE,
    BreedId INT FOREIGN KEY REFERENCES Breeds(BreedId) NOT NULL,
    BirthDate DATE NOT NULL,
    ActualHeight FLOAT NOT NULL
);

--INSERT INTO Dogs (DogId, DogName, BreedId, BirthDate, ActualHeight)
--VALUES
--    (1, 'Барон', 1, '2019-05-10', 65),
--    (2, 'Рекс', 2, '2020-02-15', 55),
--    (3, 'Лайка', 1, '2018-11-20', 60),
--    (4, 'Макс', 3, '2017-08-05', 52),
--    (5, 'Шарик', 4, '2021-01-08', 58),
--    (6, 'Тузик', 3, '2019-07-12', 68),
--    (7, 'Бобик', 5, '2020-09-25', 24),
--    (8, 'Ричи', 2, '2016-04-02', 57),
--    (9, 'Джек', 3, '2015-12-10', 69),
--    (10, 'Майло', 1, '2021-03-18', 61);

--INSERT INTO Breeds (BreedId, BreedName, MinExteriorHeight, MaxExteriorHeight)
--VALUES
--    (1, 'Немецкая овчарка', 60, 65),
--    (2, 'Лабрадор', 55, 62),
--    (3, 'Ротвейлер', 65, 70),
--    (4, 'Бульдог', 50, 55),
--    (5, 'Йоркширский терьер', 20, 25);