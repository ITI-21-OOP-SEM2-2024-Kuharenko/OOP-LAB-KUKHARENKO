﻿namespace Handler
{
     public enum Breed
    {
        Питбуль,
        Немецкая_Овчарка,
        Алабай,
        Шпиц,
        Терьер,
        Буль
    }

}
