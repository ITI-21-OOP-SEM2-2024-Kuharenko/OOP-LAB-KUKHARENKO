﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Handler
{
    /// <summary>
    /// Класс, представляющий собаку.
    /// </summary>
    public class Dog
    {
        private string _name;

        /// <summary>
        /// Имя собаки.
        /// </summary>
        public string Name
        {
            get { return _name; }
            set
            {
                if (value?.Trim() != null)
                {
                    _name = value;
                    OnPropertyChanged(nameof(_name));
                }
            }
        }

        private Breed _breed;

        /// <summary>
        /// Порода собаки.
        /// </summary>
        public Breed Breed
        {
            get { return _breed; }
            set { _breed = value; OnPropertyChanged(nameof(_breed)); }
        }

        private string _birthdate;

        /// <summary>
        /// Дата рождения собаки.
        /// </summary>
        public string Birthdate
        {
            get { return _birthdate; }
            set { _birthdate = value; OnPropertyChanged(nameof(_birthdate)); }
        }

        private int _min_height;

        /// <summary>
        /// Минимальная высота собаки.
        /// </summary>
        public int MinHeight
        {
            get { return _min_height; }
            set { _min_height = value; OnPropertyChanged(nameof(_min_height)); }
        }

        private int _max_height;

        /// <summary>
        /// Максимальная высота собаки.
        /// </summary>
        public int MaxHeight
        {
            get { return _max_height; }
            set { _max_height = value; OnPropertyChanged(nameof(_max_height)); }
        }

        private int _actual_height;

        /// <summary>
        /// Фактическая высота собаки.
        /// </summary>
        public int ActualHeight
        {
            get { return _actual_height; }
            set { _actual_height = value; OnPropertyChanged(nameof(_actual_height)); }
        }

        /// <summary>
        /// Пустой конструктор класса Dog.
        /// </summary>
        public Dog()
        {
            // Пустой конструктор
        }

        /// <summary>
        /// Конструктор класса Dog с параметрами.
        /// </summary>
        /// <param name="name">Имя собаки.</param>
        /// <param name="breed">Порода собаки.</param>
        /// <param name="birthdate">Дата рождения собаки.</param>
        /// <param name="minHeight">Минимальная высота собаки.</param>
        /// <param name="maxHeight">Максимальная высота собаки.</param>
        /// <param name="actualHeight">Фактическая высота собаки.</param>
        public Dog(string name, Breed breed, string birthdate, int minHeight, int maxHeight, int actualHeight)
        {
            Name = name?.Trim();
            Breed = breed;
            Birthdate = birthdate;
            MinHeight = minHeight;
            MaxHeight = maxHeight;
            ActualHeight = actualHeight;
        }

        /// <summary>
        /// Событие, возникающее при изменении свойств объекта.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Метод, вызываемый при изменении свойств объекта.
        /// </summary>
        /// <param name="propertyName">Имя измененного свойства.</param>
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}