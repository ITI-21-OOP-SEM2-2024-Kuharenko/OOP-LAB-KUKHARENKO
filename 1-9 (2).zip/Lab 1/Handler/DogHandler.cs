﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;
using System.Xml;

namespace Handler
{
    /// <summary>
    /// Класс, отвечающий за обработку собак.
    /// </summary>
    public class DogHandler
    {
        /// <summary>
        /// Список собак.
        /// </summary>
        public List<Dog> dogs { get; set; }

        /// <summary>
        /// Конструктор класса DogHandler.
        /// </summary>
        public DogHandler()
        {
            dogs = new List<Dog>();
        }

        /// <summary>
        /// Метод для парсинга XML-файла с информацией о собаках.
        /// </summary>
        /// <param name="xmlFilePath">Путь к XML-файлу.</param>
        public void ParseXml(string xmlFilePath)
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ValidationType = ValidationType.Schema;
            settings.Schemas.Add(null, @"D:\Laba\Cours 2\OOP C#\SEM 2\Lab 1\WpfApp\Dog.xsd");
            settings.ValidationEventHandler += ValidationCallback;

            using (XmlReader reader = XmlReader.Create(xmlFilePath, settings))
            {
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element && reader.Name == "dog")
                    {
                        Dog dog = ParseDogElement(reader.ReadSubtree());
                        dogs.Add(dog);
                    }
                }
            }
        }

        private Dog ParseDogElement(XmlReader reader)
        {
            Dog dog = new Dog();

            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element)
                {
                    switch (reader.Name)
                    {
                        case "name":
                            dog.Name = reader.ReadElementContentAsString();
                            break;
                        case "breed":
                            string breedString = reader.ReadElementContentAsString();
                            dog.Breed = (Breed)Enum.Parse(typeof(Breed), breedString, ignoreCase: true);
                            break;
                        case "birthdate":
                            dog.Birthdate = reader.ReadElementContentAsString();
                            break;
                        case "min_height":
                            string minHeightString = reader.ReadInnerXml();
                            int minHeight;
                            if (int.TryParse(minHeightString, out minHeight))
                            {
                                dog.MinHeight = minHeight;
                            }
                            break;
                        case "max_height":
                            dog.MaxHeight = reader.ReadElementContentAsInt();
                            break;
                        case "actual_height":
                            dog.ActualHeight = reader.ReadElementContentAsInt();
                            break;
                    }
                }
                else if (reader.NodeType == XmlNodeType.EndElement && reader.Name == "dog")
                {
                    break;
                }
            }

            return dog;
        }

        private void ValidationCallback(object sender, ValidationEventArgs e)
        {
            if (e.Severity == XmlSeverityType.Error)
            {
                throw new Exception($"XML validation error: {e.Message}");
            }
        }

        /// <summary>
        /// Метод для сохранения информации о собаках в XML-файл.
        /// </summary>
        /// <param name="xmlFilePath">Путь к XML-файлу.</param>
        public void SaveToXml(string xmlFilePath)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;

            using (XmlWriter writer = XmlWriter.Create(xmlFilePath, settings))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("handler");

                foreach (Dog dog in dogs)
                {
                    writer.WriteStartElement("dog");

                    writer.WriteElementString("name", dog.Name);
                    writer.WriteElementString("breed", dog.Breed.ToString());
                    writer.WriteElementString("birthdate", dog.Birthdate);
                    writer.WriteElementString("min_height", dog.MinHeight.ToString());
                    writer.WriteElementString("max_height", dog.MaxHeight.ToString());
                    writer.WriteElementString("actual_height", dog.ActualHeight.ToString());

                    writer.WriteEndElement();
                }

                writer.WriteEndElement();
                writer.WriteEndDocument();
            }
        }
    }
}