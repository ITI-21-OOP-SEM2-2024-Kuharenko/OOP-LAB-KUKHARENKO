﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;
using System.Xml;

namespace Handler
{
    [TestClass]
    public class DogHandlerTests
    {
        private string validXmlFilePath;

        [TestInitialize]
        public void Setup()
        {
            validXmlFilePath = @"D:\Laba\Cours 2\OOP C#\SEM 2\Lab 1\LibTests\bin\Debug_Valid.xml";

            using (XmlWriter writer = XmlWriter.Create(validXmlFilePath))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("handler");

                writer.WriteStartElement("dog");
                writer.WriteElementString("name", "Рэкс");
                writer.WriteElementString("breed", "Питбуль");
                writer.WriteElementString("birthdate", "21.7.2005");
                writer.WriteElementString("min_height", "58");
                writer.WriteElementString("max_height", "90");
                writer.WriteElementString("actual_height", "74");
                writer.WriteEndElement();                
                writer.WriteEndElement();
                writer.WriteEndDocument();
            }
        }

        [TestMethod]
        public void ParseXml_ValidXmlFile_ParsesDogsCorrectly()
        {
            // Arrange
            DogHandler dogHandler = new DogHandler();
            dogHandler.ParseXml(validXmlFilePath);

            // Act
            int dogCount = dogHandler.dogs.Count;

            // Assert
            Assert.AreEqual(1, dogCount);
            Assert.AreEqual("Рэкс", dogHandler.dogs[0].Name);
            Assert.AreEqual("Питбуль", dogHandler.dogs[0].Breed.ToString());
            Assert.AreEqual("21.7.2005", dogHandler.dogs[0].Birthdate);
            Assert.AreEqual(0, dogHandler.dogs[0].MinHeight);
            Assert.AreEqual(90, dogHandler.dogs[0].MaxHeight);
            Assert.AreEqual(0, dogHandler.dogs[0].ActualHeight);

        }
    }
}