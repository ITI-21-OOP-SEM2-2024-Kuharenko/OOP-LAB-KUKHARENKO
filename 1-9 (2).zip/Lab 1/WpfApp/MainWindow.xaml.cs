﻿using Handler;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp
{
    
    public partial class MainWindow : Window
    {
        DogHandler handler = new DogHandler();
        public MainWindow()
        {
            InitializeComponent();
            try
            {                
                handler.ParseXml(@"D:\\Laba\\Cours 2\\OOP C#\\SEM 2\\Lab 1\\WpfApp\\Dog.xml");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            comboBoxColumn.ItemsSource = Enum.GetValues(typeof(Breed));
            dataTable.ItemsSource = handler.dogs;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                handler.SaveToXml(@"D:\\Laba\\Cours 2\\OOP C#\\SEM 2\\Lab 1\\WpfApp\\Dog.xml");
                MessageBox.Show("Записи успешно сохранились!");
            }
            catch (ArgumentNullException)
            {
                MessageBox.Show("Одно из полей не введено!");
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Одно из полей введено некорректно!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
