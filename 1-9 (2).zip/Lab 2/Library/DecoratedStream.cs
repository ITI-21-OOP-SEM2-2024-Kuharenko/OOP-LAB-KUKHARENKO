﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class DecoratedStream : StreamDecorator
    {
        public DecoratedStream(Stream stream, TimeSpan timeout) : base(stream, timeout)
        {
        }

        public override bool CanRead => decoratedStream.CanRead;

        public override bool CanSeek => decoratedStream.CanSeek;

        public override bool CanWrite => decoratedStream.CanWrite;

        public override long Length => decoratedStream.Length;

        public override long Position
        {
            get => decoratedStream.Position;
            set => decoratedStream.Position = value;
        }

        public override void Flush()
        {
            decoratedStream.Flush();
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            return decoratedStream.Read(buffer, offset, count);
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            return decoratedStream.Seek(offset, origin);
        }

        public override void SetLength(long value)
        {
            decoratedStream.SetLength(value);
        }
    }

}
