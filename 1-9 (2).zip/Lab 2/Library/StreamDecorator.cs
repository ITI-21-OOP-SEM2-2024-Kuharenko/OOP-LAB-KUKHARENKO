﻿using System;
using System.IO;

namespace Library
{
    public abstract class StreamDecorator : Stream
    {
        protected Stream decoratedStream;
        protected TimeSpan timeout;
        protected DateTime lastWriteTime;

        public StreamDecorator(Stream stream, TimeSpan timeout)
        {
            decoratedStream = stream;
            this.timeout = timeout;
            lastWriteTime = DateTime.Now;
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            if (!IsTimeoutExceeded())
            {
                decoratedStream.Write(buffer, offset, count);
                lastWriteTime = DateTime.Now;
            }
            else
            {
                throw new Exception("Ошибка. Запись в файл после заданного таймаута.");
            }
        }

        private bool IsTimeoutExceeded()
        {
            if (lastWriteTime == null)
            {
                return false;
            }
            else
            {
                return (DateTime.Now - lastWriteTime) > timeout;
            }
        }
    }
}