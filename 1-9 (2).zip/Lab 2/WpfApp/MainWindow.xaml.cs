﻿using Library;
using Microsoft.Win32;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace StreamApp
{
    public partial class MainWindow : Window
    {
        private Stream stream;
        private DecoratedStream decoratedStream; 

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                txtFilePath.Text = openFileDialog.FileName;
            }
            // Получаем выбранный тип потока
            string selectedStream = ((ComboBoxItem)cmbStream.SelectedItem).Content.ToString();

            switch (selectedStream)
            {
                case "Memory Stream":
                    stream = new MemoryStream();
                    break;

                case "File Stream":
                    string filePath = txtFilePath.Text;

                    if (string.IsNullOrEmpty(filePath))
                    {
                        MessageBox.Show("Пожалуйста, выберите файл.");
                        return;
                    }
                    try
                    {
                        stream = new FileStream(filePath, FileMode.Create);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Не удалось создать поток файла: {ex.Message}");
                        return;
                    }

                    break;

                case "Buffered Stream":
                    stream = new BufferedStream(new MemoryStream());
                    break;

                default:
                    MessageBox.Show("Выбран недопустимый тип потока.");
                    return;
            }

            // Создаем экземпляр DecoratedStream с таймаутом 5 секунд
            TimeSpan timeout = TimeSpan.FromSeconds(3);
            decoratedStream = new DecoratedStream(stream, timeout); // Присваиваем созданный экземпляр переменной на уровне класса
        }

        private void BtnWrite_Click(object sender, RoutedEventArgs e)
        {
            // Записываем данные в поток
            string input = txtInput.Text;
            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(input);
            try
            {
               // Task.Delay(5000).Wait(); 
                decoratedStream.Write(buffer, 0, buffer.Length);
                MessageBox.Show("Запись успешно сохранена");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally 
            { 
                decoratedStream.Dispose();
                decoratedStream.Close();
            }
            // Очищаем поле выбора пути и поле ввода
            txtFilePath.Clear();
            txtInput.Clear();

        }
    }
}