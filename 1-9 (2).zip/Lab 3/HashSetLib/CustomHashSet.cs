﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace HashSetLib
{
    /// <summary>
    /// Представляет коллекцию уникальных элементов.
    /// </summary>
    /// <typeparam name="T">Тип элементов в множестве.</typeparam>
    public class CustomHashSet<T> : ICollection<T>
    {
        private const int InitialCapacity = 4;
        private const float LoadFactor = 0.75f;

        private Entry<T>[] items;
        private int count;

        /// <summary>
        /// Возвращает количество элементов в множестве.
        /// </summary>
        public int Count => count;

        /// <summary>
        /// Возвращает значение, показывающее, доступна ли коллекция только для чтения.
        /// </summary>
        public bool IsReadOnly => false;

        /// <summary>
        /// Инициализирует новый экземпляр класса HashSet.
        /// </summary>
        public CustomHashSet()
        {
            items = new Entry<T>[InitialCapacity];
            count = 0;
        }

        /// <summary>
        /// Добавляет элемент в множество.
        /// </summary>
        /// <param name="item">Элемент, который требуется добавить.</param>
        public void Add(T item)
        {
            EnsureCapacity();
            int index = GetIndex(item);
            if (items[index] == null)
            {
                items[index] = new Entry<T>(item);
                count++;
            }
        }

        /// <summary>
        /// Определяет, содержит ли множество указанный элемент.
        /// </summary>
        /// <param name="item">Элемент, который требуется найти.</param>
        /// <returns>true, если множество содержит указанный элемент; в противном случае — false.</returns>
        public bool Contains(T item)
        {
            int index = GetIndex(item);
            return items[index] != null && items[index].Value.Equals(item);
        }

        /// <summary>
        /// Удаляет указанный элемент из множества.
        /// </summary>
        /// <param name="item">Элемент, который требуется удалить.</param>
        /// <returns>true, если элемент был успешно удален; в противном случае — false.</returns>
        public bool Remove(T item)
        {
            int index = GetIndex(item);
            if (items[index] != null && items[index].Value.Equals(item))
            {
                items[index] = null;
                count--;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Копирует элементы множества в указанный массив, начиная с указанного индекса.
        /// </summary>
        /// <param name="array">Массив, в который будут скопированы элементы множества.</param>
        /// <param name="arrayIndex">Индекс в массиве, с которого начнется копирование.</param>
        public void CopyTo(T[] array, int arrayIndex)
        {
            if (array == null)
            {
                throw new ArgumentNullException(nameof(array), "Массив не может быть null.");
            }

            if (arrayIndex < 0 || arrayIndex >= array.Length)
            {
                throw new ArgumentOutOfRangeException(nameof(arrayIndex), "Недопустимый индекс массива.");
            }

            if (Count > array.Length - arrayIndex)
            {
                throw new ArgumentException("Количество элементов в исходной коллекции превышает доступное пространство от arrayIndex до конца целевого массива.");
            }

            int currentIndex = arrayIndex;
            foreach (Entry<T> entry in items)
            {
                if (entry != null)
                {
                    array[currentIndex++] = entry.Value;
                }
            }
        }

        /// <summary>
        /// Очищает множество, удаляя все элементы из него.
        /// </summary>
        public void Clear()
        {
            Array.Clear(items, 0, items.Length);
            count = 0;
        }

        /// <summary>
        /// Возвращает перечислитель, осуществляющий перебор элементов множества.
        /// </summary>
        /// <returns>Перечислитель, который можно использовать для итерации по коллекции.</returns>
        public IEnumerator<T> GetEnumerator()
        {
            foreach (Entry<T> entry in items)
            {
                if (entry != null)
                {
                    yield return entry.Value;
                }
            }
        }

        /// <summary>
        /// Возвращает перечислитель, осуществляющий перебор элементов множества.
        /// </summary>
        /// <returns>Объект IEnumerator, который можно использовать для итерации по коллекции.</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        private int GetIndex(T item)
        {
            return Math.Abs(item.GetHashCode()) % items.Length;
        }

        private void EnsureCapacity()
        {
            if ((float)count / items.Length >= LoadFactor)
            {
                Resize();
            }
        }

        private void Resize()
        {
            int newCapacity = items.Length * 2;
            var newItems = new Entry<T>[newCapacity];
            foreach (Entry<T> entry in items)
            {
                if (entry != null)
                {
                    int newIndex = Math.Abs(entry.Value.GetHashCode()) % newCapacity;
                    newItems[newIndex] = entry;
                }
            }
            items = newItems;
        }

        private class Entry<TValue>
        {
            public TValue Value { get; }
            public Entry(TValue value)
            {
                Value = value;
            }
        }
    }
}
