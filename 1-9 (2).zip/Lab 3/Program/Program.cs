﻿using System;

namespace HashSetLib
{
    class Program
    {
        static void Main(string[] args)
        {
            // Создаем экземпляр CustomHashSet<int>
            CustomHashSet<int> set = new CustomHashSet<int>();

            // Добавляем элементы в множество
            set.Add(1);
            set.Add(2);
            set.Add(2);
            set.Add(2);
            set.Add(3);
            set.Add(4);
            set.Add(4);
            set.Add(5);

            // Выводим количество элементов в множестве
            Console.WriteLine("Количество элементов в множестве: " + set.Count);

            // Проверяем наличие элемента в множестве
            Console.WriteLine("Множество содержит элемент 2: " + set.Contains(2));

            // Удаляем элемент из множества
            set.Remove(3);

            // Выводим количество элементов в множестве после удаления
            Console.WriteLine("Количество элементов в множестве после удаления: " + set.Count);
            
            //Выводим HashSet после удаления
            foreach (int i in set)
            {
                Console.WriteLine(i);
            }

            // Создаем массив и копируем элементы множества в массив
            int[] array = new int[set.Count];
            set.CopyTo(array, 0);

            // Выводим элементы массива
            Console.WriteLine("Элементы массива:");
            foreach (int item in array)
            {
                Console.WriteLine(item);
            }

            // Очищаем множество
            set.Clear();

            // Выводим количество элементов в множестве после очистки
            Console.WriteLine("Количество элементов в множестве после очистки: " + set.Count);

            Console.ReadLine();
        }
    }
}
