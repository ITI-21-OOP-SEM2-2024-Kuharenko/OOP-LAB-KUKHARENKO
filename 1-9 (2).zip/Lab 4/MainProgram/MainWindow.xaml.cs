﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace WpfDynamicInterface
{
    public partial class MainWindow : Window
    {
        private TextBox textBox;

        public MainWindow()
        {
            Loaded += MainWindow_Load;
        }
        
        public void MainWindow_Load(object sender, RoutedEventArgs e)
        {
            InitializeComponent();
            CreateDynamicInterface();
        }

        private void CreateDynamicInterface()
        {
            // Создание Grid для размещения элементов управления
            Grid mainGrid = new Grid();

            // Определение строк и столбцов в Grid
            mainGrid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Auto) });
            mainGrid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Auto) });
            mainGrid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });

            // Создание элементов управления
            Button openButton = new Button() { Content = "Открыть" };
            Button copyButton = new Button() { Content = "Копировать" };
            Button saveButton = new Button() { Content = "Сохранить" };
            Button pasteButton = new Button() { Content = "Вставить" };

            textBox = new TextBox();

            // Установка позиций элементов управления в Grid
            Grid.SetRow(openButton, 0);
            Grid.SetColumn(openButton, 0);

            Grid.SetRow(copyButton, 0);
            Grid.SetColumn(copyButton, 1);

            Grid.SetRow(saveButton, 1);
            Grid.SetColumn(saveButton, 0);

            Grid.SetRow(pasteButton, 1);
            Grid.SetColumn(pasteButton, 1);

            Grid.SetRow(textBox, 2);
            Grid.SetColumn(textBox, 0);
            Grid.SetColumnSpan(textBox, 2);

            // Добавление элементов управления в Grid
            mainGrid.Children.Add(openButton);
            mainGrid.Children.Add(copyButton);
            mainGrid.Children.Add(saveButton);
            mainGrid.Children.Add(pasteButton);
            mainGrid.Children.Add(textBox);

            // Назначение обработчиков событий
            openButton.Click += (sender, e) => OpenButton_Click();
            copyButton.Click += (sender, e) => CopyButton_Click();
            saveButton.Click += SaveButton_Click;
            pasteButton.Click += PasteButton_Click;

            // Установка Grid в качестве содержимого окна
            Content = mainGrid;
        }

        private void OpenButton_Click()
        {
            // Создание и настройка диалогового окна открытия файла
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
                Title = "Открыть файл"
            };

            // Отображение диалогового окна и обработка результата
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                try
                {
                    // Чтение содержимого файла и вывод в TextBox
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        string fileContent = reader.ReadToEnd();
                        textBox.Text = fileContent;
                    }
                    MessageBox.Show($"Файл успешно открыт: {filePath}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при открытии файла: {ex.Message}");
                }
            }
        }

        private void CopyButton_Click()
        {
            // Обработка события нажатия на кнопку "Копировать"
            string textToCopy = textBox.Text;
            if (!string.IsNullOrEmpty(textToCopy))
            {
                Clipboard.SetText(textToCopy);
                MessageBox.Show("Текст скопирован в буфер обмена.");
            }
            else
            {
                MessageBox.Show("Нет текста для копирования.");
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Обработка события нажатия на кнопку "Сохранить"
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
                Title = "Сохранить файл"
            };

            if (saveFileDialog.ShowDialog() == true)
            {

                string filePath = saveFileDialog.FileName;
                try
                {
                    using (StreamWriter writer = new StreamWriter(filePath))
                    {
                        writer.Write(textBox.Text);
                    }
                    MessageBox.Show($"Файл успешно сохранен: {filePath}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении файла: {ex.Message}");
                }
            }
        }

        private void PasteButton_Click(object sender, RoutedEventArgs e)
        {
            // Обработка события нажатия на кнопку "Вставить"
            string clipboardText = Clipboard.GetText();
            textBox.SelectedText = clipboardText;
            MessageBox.Show("Текст вставлен из буфера обмена.");
        }
    }
}