﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace TextEditorApp
{
    public class TextEditor
    {
        private TextBox textBox;

        public void Run()
        {
            // Создание главного окна
            Window mainWindow = new Window
            {
                Title = "Text Editor",
                Width = 400,
                Height = 300,
                WindowStartupLocation = WindowStartupLocation.CenterScreen
            };

            // Создание TextBox для ввода текста
            textBox = new TextBox();

            // Создание кнопки "Открыть"
            Button openButton = CreateButton("Открыть", () =>
            {
                // Логика обработки события нажатия кнопки "Открыть"
                MessageBox.Show("Вы нажали кнопку \"Открыть\"");
            });

            // Создание кнопки "Сохранить"
            Button saveButton = CreateButton("Сохранить", () =>
            {
                // Логика обработки события нажатия кнопки "Сохранить"
                MessageBox.Show("Вы нажали кнопку \"Сохранить\"");
            });

            // Создание кнопки "Сохранить выделенный текст в буфер"
            Button copyButton = CreateButton("Копировать", CopyButton_Click);

            // Создание кнопки "Вставить из буфера"
            Button pasteButton = CreateButton("Вставить", PasteButton_Click);

            // Создание контейнера StackPanel и добавление в него всех элементов управления
            StackPanel stackPanel = new StackPanel();
            stackPanel.Children.Add(textBox);
            stackPanel.Children.Add(openButton);
            stackPanel.Children.Add(saveButton);
            stackPanel.Children.Add(copyButton);
            stackPanel.Children.Add(pasteButton);

            // Установка StackPanel в качестве содержимого окна
            mainWindow.Content = stackPanel;

            // Отображение окна
            mainWindow.ShowDialog();
        }

        private Button CreateButton(string text, Action onClick)
        {
            Button button = new Button
            {
                Content = text,
                Margin = new Thickness(5),
                Padding = new Thickness(10),
                Width = 100
            };

            // Добавление события Click
            button.Click += (sender, e) => onClick.Invoke();

            return button;
        }

        private void CopyButton_Click()
        {
            // Логика обработки события нажатия кнопки "Копировать"
            MessageBox.Show("Вы нажали кнопку \"Копировать\"");
        }

        private void PasteButton_Click()
        {
            // Логика обработки события нажатия кнопки "Вставить"
            MessageBox.Show("Вы нажали кнопку \"Вставить\"");
        }
    }
}