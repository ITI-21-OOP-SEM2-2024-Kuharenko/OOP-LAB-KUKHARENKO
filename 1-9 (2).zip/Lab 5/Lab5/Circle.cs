﻿using CircleMovementExample;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleMovementExample
{
    public class Circle
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        public int Radius { get; private set; }
        public Direction CurrentDirection { get; private set; }

        public event EventHandler DirectionChanged;

        public Circle(int x, int y, int radius)
        {
            X = x;
            Y = y;
            Radius = radius;
            CurrentDirection = Direction.Right;
        }

        public void Move()
        {
            // Изменяем координаты круга в зависимости от текущего направления

            switch (CurrentDirection)
            {
                case Direction.Left:
                    X -= 1;
                    break;
                case Direction.Right:
                    X += 1;
                    break;
                case Direction.Up:
                    Y -= 1;
                    break;
                case Direction.Down:
                    Y += 1;
                    break;
            }
        }

        public void ChangeDirection(Direction newDirection)
        {
            // Изменяем текущее направление и вызываем событие при смене направления

            if (newDirection != CurrentDirection)
            {
                CurrentDirection = newDirection;
                OnDirectionChanged();
            }
        }

        protected virtual void OnDirectionChanged()
        {




            DirectionChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
