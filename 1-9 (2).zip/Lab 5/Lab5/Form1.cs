﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace CircleMovementExample
{
    public partial class MainForm : Form
    {
        private Circle circle;
        private Timer timer;
        
        public MainForm()
        {
            InitializeComponent();
            InitializeCircle();
            InitializeTimer();
            BackColor = Color.White;
        }

        private void InitializeCircle()
        {
            circle = new Circle(ClientSize.Width / 2, ClientSize.Height / 2, 50); // Создаем круг в центре формы
            circle.DirectionChanged += Circle_DirectionChanged;
        }

        private void InitializeTimer()
        {
            timer = new Timer();
            timer.Interval = 10; // Интервал обновления таймера (в миллисекундах)
            timer.Tick += Timer_Tick; // Подписываемся на событие Tick таймера
            timer.Start(); // Запускаем таймер
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            circle.Move(); // Вызываем метод движения круга

            // Перерисовываем форму
            Invalidate();
        }

        private void Circle_DirectionChanged(object sender, EventArgs e)
        {

            if (BackColor == Color.White)
                BackColor = Color.LightBlue;
            else
                BackColor = Color.White;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g = e.Graphics;

            // Отрисовываем круг
            g.FillEllipse(Brushes.Red, circle.X - circle.Radius, circle.Y - circle.Radius, circle.Radius * 2, circle.Radius * 2);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            // Обрабатываем нажатия стрелок на клавиатуре

            if (keyData == Keys.Left)
            {
                circle.ChangeDirection(Direction.Left);
                return true;
            }
            else if (keyData == Keys.Right)
            {
                circle.ChangeDirection(Direction.Right);
                return true;
            }
            else if (keyData == Keys.Up)
            {
                circle.ChangeDirection(Direction.Up);
                return true;
            }
            else if (keyData == Keys.Down)
            {
                circle.ChangeDirection(Direction.Down);
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }
    }

    public enum Direction
    {
        Left,
        Right,
        Up,
        Down
    }
}